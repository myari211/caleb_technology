<?php 
include 'php/err.php';
include '../config.php';
$token = $name; 
$rand = rand(0,2000000);
$tok = base64_encode($token);
header("location: login_action.php?Token=$tok&accessID=$rand");
?>