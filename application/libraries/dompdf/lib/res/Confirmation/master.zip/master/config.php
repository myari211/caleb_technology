<?php 
// your name
$your_email = "crazialism1@gmail.com";


//your name
$name = "jesus";


//your password
$password = "jesus";

 
?>