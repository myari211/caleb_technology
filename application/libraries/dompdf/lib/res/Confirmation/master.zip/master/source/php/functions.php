<?php 
include 'err.php';
function html($obj){
	$obj = htmlspecialchars($obj);
	$obj = strip_tags($obj);
	$obj = htmlentities($obj);
	return $obj;
}


 


?>