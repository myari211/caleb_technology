/* Utilidades js para el sitio de masterconsultas */

	//functions that close and open a dialog, the parameter "nameDialog" must have the next
	//structure: "nameOfMyDialog"
	function closeDialog(nameDialog){
		removeGeneratedExtraDialogs(nameDialog);
		$("#"+nameDialog+"").dialog("close");
	}
	function openDialog(nameDialog){
		removeGeneratedExtraDialogs(nameDialog);
		$("#"+nameDialog+"").dialog('open');
	}
		
	function removeGeneratedExtraDialogs(dialogId){
		var firstFound=false;
		$('div[id="'+dialogId+'"]').each(function(index) {
			if(firstFound==false){
		    	firstFound=true;
			}else{
		    	$(this).dialog('destroy').remove();
			}
		});
	}
	
	//bloqueo de interfaz
	function blockUI(){
		$.blockUI({ message: '<h1>Espere por favor ...</h1>' });
	}
	function unblockUI(){
		$.unblockUI();
	}
	$.subscribe('unblockUITopic', function(event, eventUi) {
		unblockUI();
	});
	function attachBlockUI(){
		$('a[blocksui="true"], input[type="submit"][blocksui="true"]').each(function(index) {
			var currentOnClick = this.onclick;
	    	this.onclick = function() {
	    		blockUI();
	        	if (currentOnClick) {
	            	currentOnClick();
	        	}
		    };
		});
	}
	
	//function that submit a form, previously load a specific action
	function goAction(idForm,actionName){
			form = document.getElementById(idForm);
			form.action = actionName;
	}
	
	function goActionSubmit(idForm,actionName){
			form = document.getElementById(idForm);
			form.action = actionName;
			form.submit();
	}
	
	//agregar y eleminar clases del estilo de un elemento
	function addClass(idElement,clazz){
		$("#"+idElement+"").addClass(clazz);
	}
	
	function removeClass(idElement,clazz){
		$("#"+idElement+"").removeClass(clazz);
	}